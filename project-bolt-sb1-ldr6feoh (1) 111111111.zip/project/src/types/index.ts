export interface Calculation {
  id: string;
  type: 'percentage-of' | 'what-percent' | 'increase-decrease';
  input1: number;
  input2: number;
  result: number;
  timestamp: Date;
  formula: string;
}

export interface GSTCalculation {
  id: string;
  type: 'add-gst' | 'remove-gst';
  baseAmount: number;
  gstRate: number;
  gstAmount: number;
  totalAmount: number;
  timestamp: Date;
  formula: string;
}

export interface CalculationHistory {
  calculations: Calculation[];
}

export interface GSTCalculationHistory {
  calculations: GSTCalculation[];
}

export type Theme = 'light' | 'dark';

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  readTime: string;
  publishDate: string;
}

export interface GSTBreakdown {
  baseAmount: number;
  gstAmount: number;
  totalAmount: number;
  gstRate: number;
}