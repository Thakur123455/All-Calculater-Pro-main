import React from 'react';
import { Clock, Trash2, Copy } from 'lucide-react';
import type { Calculation } from '../types';
import { formatNumber } from '../utils/calculations';

interface CalculationHistoryProps {
  calculations: Calculation[];
  onClearHistory: () => void;
}

const CalculationHistory: React.FC<CalculationHistoryProps> = ({
  calculations,
  onClearHistory
}) => {
  const copyResult = async (result: number) => {
    try {
      await navigator.clipboard.writeText(formatNumber(result));
    } catch (err) {
      console.error('Failed to copy result:', err);
    }
  };

  const formatTimestamp = (timestamp: Date) => {
    return new Date(timestamp).toLocaleString();
  };

  if (calculations.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            No calculations yet
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            Your calculation history will appear here as you use the calculator.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
          Calculation History
        </h2>
        <button
          onClick={onClearHistory}
          className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-all duration-200 flex items-center space-x-2 hover:scale-105"
        >
          <Trash2 className="h-4 w-4" />
          <span>Clear History</span>
        </button>
      </div>

      <div className="space-y-4">
        {calculations.slice().reverse().map((calculation) => (
          <div
            key={calculation.id}
            className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div className="flex-1 mb-4 md:mb-0">
                <p className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                  {calculation.formula}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {formatTimestamp(calculation.timestamp)}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    {formatNumber(calculation.result)}
                  </p>
                </div>
                <button
                  onClick={() => copyResult(calculation.result)}
                  className="p-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-all duration-200 hover:scale-105"
                  title="Copy result"
                >
                  <Copy className="h-4 w-4 text-gray-600 dark:text-gray-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalculationHistory;