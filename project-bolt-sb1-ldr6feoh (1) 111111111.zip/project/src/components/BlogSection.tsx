import React from 'react';
import { Clock, TrendingUp, DollarSign, ShoppingCart, Calculator, BookOpen } from 'lucide-react';
import type { BlogPost } from '../types';

const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'Understanding Percentage in Business Finance',
    excerpt: 'Learn how percentages are crucial for calculating profit margins, growth rates, and financial ratios in business operations.',
    content: '',
    category: 'Business',
    readTime: '5 min read',
    publishDate: '2024-01-15'
  },
  {
    id: '2',
    title: 'Smart Shopping: Using Percentages for Discounts',
    excerpt: 'Master the art of calculating discounts, comparing deals, and understanding markup percentages to save money while shopping.',
    content: '',
    category: 'Shopping',
    readTime: '4 min read',
    publishDate: '2024-01-12'
  },
  {
    id: '3',
    title: 'Investment Returns and Percentage Growth',
    excerpt: 'Discover how to calculate investment returns, compound interest, and understand percentage-based financial growth.',
    content: '',
    category: 'Finance',
    readTime: '7 min read',
    publishDate: '2024-01-10'
  },
  {
    id: '4',
    title: 'Academic Grading Systems and Percentages',
    excerpt: 'Explore how percentages work in educational settings, from test scores to GPA calculations and academic performance metrics.',
    content: '',
    category: 'Education',
    readTime: '6 min read',
    publishDate: '2024-01-08'
  },
  {
    id: '5',
    title: 'Data Analysis: Percentage Change in Statistics',
    excerpt: 'Learn to interpret statistical data using percentage changes, year-over-year growth, and comparative analysis techniques.',
    content: '',
    category: 'Analytics',
    readTime: '8 min read',
    publishDate: '2024-01-05'
  },
  {
    id: '6',
    title: 'Real Estate and Percentage Calculations',
    excerpt: 'Understand how percentages apply to real estate transactions, including down payments, mortgage rates, and property appreciation.',
    content: '',
    category: 'Real Estate',
    readTime: '5 min read',
    publishDate: '2024-01-03'
  }
];

const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'Business':
      return <TrendingUp className="h-5 w-5" />;
    case 'Finance':
      return <DollarSign className="h-5 w-5" />;
    case 'Shopping':
      return <ShoppingCart className="h-5 w-5" />;
    case 'Education':
      return <BookOpen className="h-5 w-5" />;
    default:
      return <Calculator className="h-5 w-5" />;
  }
};

const BlogSection: React.FC = () => {
  return (
    <section id="blog\" className="bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-blue-900/20 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 bg-clip-text text-transparent mb-6">
            Percentage in Real Life
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Discover how percentages impact every aspect of our daily lives, from business decisions to personal finance management.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article
              key={post.id}
              className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-2xl p-6 border border-gray-200 dark:border-gray-700 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2 px-3 py-1 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                  {getCategoryIcon(post.category)}
                  <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                    {post.category}
                  </span>
                </div>
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <Clock className="h-4 w-4 mr-1" />
                  {post.readTime}
                </div>
              </div>

              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-200">
                {post.title}
              </h3>

              <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                {post.excerpt}
              </p>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {new Date(post.publishDate).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </span>
                <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium text-sm transition-colors duration-200">
                  Read More →
                </button>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            View All Articles
          </button>
        </div>
      </div>
    </section>
  );
};

export default BlogSection;