import React from 'react';
import { Clock, Trash2, Copy, FileText } from 'lucide-react';
import type { GSTCalculation } from '../types';
import { formatCurrency, formatNumber } from '../utils/gstCalculations';

interface GSTCalculationHistoryProps {
  calculations: GSTCalculation[];
  onClearHistory: () => void;
}

const GSTCalculationHistory: React.FC<GSTCalculationHistoryProps> = ({
  calculations,
  onClearHistory
}) => {
  const copyResult = async (calculation: GSTCalculation) => {
    const resultText = `Base: ${formatCurrency(calculation.baseAmount)}, GST: ${formatCurrency(calculation.gstAmount)}, Total: ${formatCurrency(calculation.totalAmount)}`;
    try {
      await navigator.clipboard.writeText(resultText);
    } catch (err) {
      console.error('Failed to copy result:', err);
    }
  };

  const formatTimestamp = (timestamp: Date) => {
    return new Date(timestamp).toLocaleString();
  };

  if (calculations.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            No GST calculations yet
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            Your GST calculation history will appear here as you use the calculator.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
          GST Calculation History
        </h2>
        <button
          onClick={onClearHistory}
          className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-all duration-200 flex items-center space-x-2 hover:scale-105"
        >
          <Trash2 className="h-4 w-4" />
          <span>Clear History</span>
        </button>
      </div>

      <div className="space-y-4">
        {calculations.slice().reverse().map((calculation) => (
          <div
            key={calculation.id}
            className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between">
              <div className="flex-1 mb-4 lg:mb-0">
                <div className="flex items-center space-x-2 mb-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    calculation.type === 'add-gst' 
                      ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300'
                      : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                  }`}>
                    {calculation.type === 'add-gst' ? 'Added GST' : 'Removed GST'}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {calculation.gstRate}% GST
                  </span>
                </div>
                <p className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                  {calculation.formula}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {formatTimestamp(calculation.timestamp)}
                </p>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Base</p>
                      <p className="font-semibold text-gray-900 dark:text-gray-100">
                        {formatCurrency(calculation.baseAmount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">GST</p>
                      <p className="font-semibold text-green-600 dark:text-green-400">
                        {formatCurrency(calculation.gstAmount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Total</p>
                      <p className="font-bold text-lg bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                        {formatCurrency(calculation.totalAmount)}
                      </p>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => copyResult(calculation)}
                  className="p-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-all duration-200 hover:scale-105"
                  title="Copy result"
                >
                  <Copy className="h-4 w-4 text-gray-600 dark:text-gray-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GSTCalculationHistory;