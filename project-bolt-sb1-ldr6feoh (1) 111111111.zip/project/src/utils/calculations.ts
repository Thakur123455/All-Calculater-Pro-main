export const calculatePercentageOf = (percentage: number, value: number): number => {
  return (percentage / 100) * value;
};

export const calculateWhatPercent = (value: number, total: number): number => {
  if (total === 0) return 0;
  return (value / total) * 100;
};

export const calculatePercentageIncrease = (originalValue: number, percentage: number): number => {
  return originalValue + (originalValue * percentage / 100);
};

export const calculatePercentageDecrease = (originalValue: number, percentage: number): number => {
  return originalValue - (originalValue * percentage / 100);
};

export const formatNumber = (num: number): string => {
  if (Number.isInteger(num)) {
    return num.toString();
  }
  return parseFloat(num.toFixed(6)).toString();
};

export const validateInput = (value: string): { isValid: boolean; error?: string } => {
  if (value.trim() === '') {
    return { isValid: false, error: 'This field is required' };
  }
  
  const num = parseFloat(value);
  if (isNaN(num)) {
    return { isValid: false, error: 'Please enter a valid number' };
  }
  
  return { isValid: true };
};